$(document).ready(function(){

    LoadJSON ('GET','https://api.myjson.com/bins/b6eod', function(res){
        render($('#main-jobs-template').html(), '.job-main', res);
        render($('#job-table-template').html(), '.job-table', res);
        render($('#job-table-template-2').html(), '.job-table-2', res);


        
    });


    function LoadJSON(type , url , callback){

        $.ajax({
            'type': type,
            'url' : url,
            'success': callback
        });
    }

    function render(t, id, data){
        var template = Handlebars.compile(t);
        var html = template(data);
        $(id).append(html);

    };

    $('table#users').DataTable();
    $('#users-2').DataTable();

    
});
